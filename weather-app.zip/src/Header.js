export default function Header() {
    return (
      <div style={{ backgroundColor: '#3D6089', color: '#fff', fontSize: '20px', padding: '10px', textAlign: 'center' }}>
          Weather-App
          </div>
    )
  }