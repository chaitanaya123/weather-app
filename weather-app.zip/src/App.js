import Header from "./Header"
import Search from "./Search"
export default function App() {
  return (
    <div>
      <Header/>
      <Search/>
    </div>
  )
}
